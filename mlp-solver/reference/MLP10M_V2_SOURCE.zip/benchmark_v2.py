"""Validation search selection followed by a freshly generated excluded test."""
import argparse,datetime,json,random,time
from pathlib import Path
from evaluation_base import run_search,verify_formulas,sha,save
from corpus import generate

def public(tasks):return [{k:v for k,v in t.items() if k not in ('ast','template_key')} for t in tasks]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    a.out.mkdir(parents=True,exist_ok=False);root=a.run;models=root/'models';started=time.monotonic()
    validation=json.loads((root/'corpus/validation.json').read_text());rng=random.Random(18105004)
    selected=[]
    for family in ('money','calendar','state'):
        pool=[t for t in validation if t['family']==family];selected+=rng.sample(pool,min(20,len(pool)))
    candidates={'heuristic':('heuristic',None),
        'round1_neural':('neural',models/'round1/best.npz'),
        'round1_hybrid16':('hybrid16',models/'round1/best.npz'),
        'round2_neural':('neural',models/'round2/best.npz'),
        'round2_hybrid16':('hybrid16',models/'round2/best.npz'),
        'round2_hybrid64':('hybrid64',models/'round2/best.npz'),
        'small':('neural',models/'small/best.npz')}
    save(a.out/'selection_protocol.json',{'tasks':[t['id'] for t in selected], 'milliseconds':750,
        'candidates':{k:[mode,str(path)] for k,(mode,path) in candidates.items()},
        'criterion':'Max oracle passes, then fewer false fits, then lower total wall time',
        'training_refresh_uses_train_only':True,'test_generated':False})
    preds={}
    for name,(mode,path) in candidates.items():preds[name],_=run_search(public(selected),mode,path,750,a.out,'validation_'+name)
    validation_report,_,_=verify_formulas(selected,preds,750);save(a.out/'validation_results.json',validation_report)
    order=lambda k:(-validation_report[k]['passes_256_new_inputs'],validation_report[k]['false_fits'],validation_report[k]['search_seconds'])
    recommendation=min(candidates,key=order)
    neural=min(('round1_neural','round2_neural'),key=order)
    hybrid=min(('round1_hybrid16','round2_hybrid16','round2_hybrid64'),key=order)
    modes={k:candidates[k] for k in ('heuristic',neural,hybrid,'small')}
    here=Path(__file__).parent
    frozen={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recommended':recommendation,
        'selected_neural':neural,'selected_hybrid':hybrid,'selection':'Validation search+256 independent oracle inputs',
        'models':{k:sha(path) for k,(_,path) in candidates.items() if path},
        'source_hashes':{str(p.relative_to(here)):sha(p) for p in sorted(here.rglob('*.py'))},
        'test_ms':1000,'test_tasks':120,'long_tasks':30,'long_ms':3000,'seed':18106099,
        'max_candidates':100000,'test_read':False}
    save(a.out/'frozen_before_test.json',frozen)
    old=json.loads((here/'prior_exclusions.json').read_text());new=json.loads((root/'corpus/exclusions.json').read_text())
    generate(a.out/'sealed_test',counts=(0,0,120),seed=frozen['seed'],
        exclude=set(old['templates'])|set(new['templates']),
        exclude_semantics=set(old['sampled_semantics'])|set(new['sampled_semantics']))
    tasks=json.loads((a.out/'sealed_test/test_public.json').read_text());preds={};long={}
    for name,(mode,path) in modes.items():preds[name],_=run_search(tasks,mode,path,1000,a.out,name)
    for name in reversed(modes):
        mode,path=modes[name];long[name],_=run_search(tasks[:30],mode,path,3000,a.out,'long_'+name)
    save(a.out/'predictions_frozen.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'hashes':{p.name:sha(p) for p in a.out.glob('*.jsonl') if not p.name.startswith('validation')}})
    for k,expected in frozen['source_hashes'].items():assert sha(here/k)==expected
    for k,expected in frozen['models'].items():assert sha(candidates[k][1])==expected
    private=json.loads((a.out/'sealed_test/test.json').read_text())
    report,passed,checks=verify_formulas(private,preds,1000);lr,lp,lc=verify_formulas(private[:30],long,3000)
    paired={};rng=random.Random(811567)
    for name in report:
        if name=='heuristic':continue
        diff=[int(x)-int(y) for x,y in zip(passed[name],passed['heuristic'])]
        boot=sorted(sum(rng.choice(diff) for _ in diff)/len(diff) for _ in range(3000))
        paired[name]={'wins':diff.count(1),'losses':diff.count(-1),'difference_pp':100*sum(diff)/len(diff),
                      'bootstrap95_pp':[100*boot[75],100*boot[2924]]}
    result={'status':'complete','seconds':time.monotonic()-started,'validation_recommendation':recommendation,
        'modes':report,'long_budget_modes':lr,'passed_by_task':passed,'long_passed_by_task':lp,
        'paired_vs_heuristic':paired,'oracle_checks':checks+lc,'runtime_llm_calls':0,
        'scope':'Supplied DSL compositions; not t0-t7 accuracy or proof of universal recovery',
        'test_generated_after_selection':True,'model_source_hashes_unchanged':True}
    save(a.out/'results.json',result);print('BENCHMARK_COMPLETE '+json.dumps(result),flush=True)

if __name__=='__main__':main()
