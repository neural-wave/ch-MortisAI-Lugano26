"""No UI interaction needed after launch; persist progress and downloadable ZIP."""
import datetime,json,os,subprocess,sys,time,traceback,zipfile,hashlib
from pathlib import Path
ROOT=Path('/content/mlp10m_v2_20261018');HERE=Path(__file__).parent
def status(**kw):
    kw['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT/'STATUS.json').write_text(json.dumps(kw,indent=2))
def run(script,*args):
    phase='training' if script=='train_v2.py' else 'evaluation'
    status(phase=phase,status='running')
    with (ROOT/(phase+'.log')).open('w') as log:
        r=subprocess.run([sys.executable,'-u',str(HERE/script),*map(str,args)],stdout=log,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(phase+' exited '+str(r.returncode)+'; see '+str(log.name))
if __name__=='__main__':
    ROOT.mkdir(exist_ok=True);start=time.monotonic()
    try:
        run('train_v2.py','--out',ROOT/'run1','--tasks','12000','--workers','8')
        run('benchmark_v2.py','--run',ROOT/'run1','--out',ROOT/'evaluation')
        status(phase='complete',status='complete',seconds=time.monotonic()-start)
    except Exception as error:
        status(phase='failed',status='failed',error=str(error),traceback=traceback.format_exc())
        raise
    finally:
        path=ROOT/'MLP10M_V2_RESULTS.zip'
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
            for p in ROOT.rglob('*'):
                if p.is_file() and p!=path and p.suffix not in ('.pt',) and '__pycache__' not in p.parts:
                    archive.write(p,p.relative_to(ROOT))
        (ROOT/'DOWNLOAD_READY.json').write_text(json.dumps({'file':str(path),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
